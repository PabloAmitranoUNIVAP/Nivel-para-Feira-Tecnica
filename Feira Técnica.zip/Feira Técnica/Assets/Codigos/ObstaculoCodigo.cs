﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstaculoCodigo : MonoBehaviour {
	float XInicial, XFinal;
	float Tempo;
	public float Velocidade, VelocidadeAngular;

	Transform ObjetoTransform;	

	// Use this for initialization
	void Start () {
		ObjetoTransform = GetComponent<Transform>();
		XInicial = ObjetoTransform.position.x;
		XFinal = XInicial - 60;
		Tempo = 0;
		if (Velocidade == 0){
			Velocidade = 1;
			print("Velocidade é nulo.");
		}
	}
	
	// Update is called once per frame
	void Update () {
		Tempo += Time.deltaTime * Velocidade;
		ObjetoTransform.position = new Vector3(Mathf.Lerp(XInicial, XFinal, Tempo), ObjetoTransform.position.y, 0);
		ObjetoTransform.rotation = ObjetoTransform.rotation * Quaternion.Euler(0, 0, VelocidadeAngular);
		if (Tempo > 1) Destroy(ObjetoTransform.gameObject);
	}
}
