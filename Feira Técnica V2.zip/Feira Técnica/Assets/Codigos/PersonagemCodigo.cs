﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PersonagemCodigo : MonoBehaviour {
	float velocidadeYp;
	float velocidadeXp;
	float alvovelocidadeXp;
	Vector2 Vetorvelocidadepersonagem;
	Rigidbody2D CorpoRigidoPersonagem;
	Transform PersonagemTransform;
	bool Apertoupulo, Machucar = true;

	float accel = 0, accelmax = 6;
	float Direcao;

	public int Vida, VidaMaxima;
	public Text VidaTexto;

	public float Tempo;
	public Text TempoTexto;

	public GameObject Bala;
	bool PodeTirar = true;

	PhysicsMaterial2D Atrito;

	// Use this for initialization
	void Start () {
		velocidadeXp = 0f;
		velocidadeYp = 0f;

		CorpoRigidoPersonagem = GetComponent<Rigidbody2D>();
		Apertoupulo = false;
		Vetorvelocidadepersonagem = new Vector2 (velocidadeXp, velocidadeYp);
		PersonagemTransform = GetComponent<Transform>();
		Atrito = new PhysicsMaterial2D();
		Atrito.friction = 0;
		CorpoRigidoPersonagem.sharedMaterial = Atrito;
	}
	
	// Update is called once per frame
	void Update () {
		Voar();

		if (Vida > VidaMaxima) Vida = VidaMaxima;
		VidaTexto.text = "Vida: " + Vida.ToString() + '/' + VidaMaxima.ToString();
		
		if (Vida <= 0) SceneManager.LoadScene("GameOver");

		if (Tempo >= 0){
			Tempo -= Time.deltaTime;
			TempoTexto.text = "Tempo: " + Mathf.Round(Tempo).ToString() + 's';
		}
		else SceneManager.LoadScene("Fim");

		if (Input.GetMouseButton(0) && PodeTirar == true){
			GameObject NovaBala = Instantiate(Bala);
			NovaBala.transform.position = PersonagemTransform.position + new Vector3(2, 0, 0);
			PodeTirar = false;
			Invoke("PermitirTiro", 0.25f);
		}
	}

	void PermitirTiro(){
		PodeTirar = true;
	}

	void PodeMachucar(){
		Machucar = true;
	}

	void Voar(){
		Apertoupulo = Input.GetButton ("Jump");
		Direcao = Input.GetAxis("Horizontal");
		if (Apertoupulo == true) velocidadeYp = 6;
		else velocidadeYp = CorpoRigidoPersonagem.velocity.y;

		if (velocidadeYp < 0) velocidadeYp -= accel * 0.03f;
		
		velocidadeXp = Mathf.MoveTowards(CorpoRigidoPersonagem.velocity.x, (7 + accel) * Direcao, 14 * Time.deltaTime);
		if (velocidadeXp != 0 || velocidadeYp < 0){
			if (accel < accelmax) accel += Time.deltaTime*3;
			else accel = accelmax;
		}
		else accel = 0;

		Vetorvelocidadepersonagem = new Vector2 (velocidadeXp, velocidadeYp);
		CorpoRigidoPersonagem.velocity = Vetorvelocidadepersonagem;
	}

	void OnTriggerEnter2D(Collider2D Objeto){
		string Tag = Objeto.gameObject.tag;
		Transform ObjetoTransform = Objeto.gameObject.transform;
		bool ExplosaoTag = Objeto.gameObject.CompareTag("PerigoExplosao");
		if ((Objeto.gameObject.CompareTag("Perigo") || ExplosaoTag) && Machucar == true){
			Vida -= 1;
			Machucar = false;

			if (ExplosaoTag == false) Destroy(Objeto.gameObject);
			Invoke("PodeMachucar", 1f);
		}
	}
}