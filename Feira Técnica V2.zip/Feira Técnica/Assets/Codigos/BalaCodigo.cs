﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BalaCodigo : MonoBehaviour {
	public float Duracao, Velocidade;

	float Tempo;
	Rigidbody2D CorpoRigido;

	// Use this for initialization
	void Start () {
		CorpoRigido = GetComponent<Rigidbody2D>();
		Tempo = 0;
	}
	
	// Update is called once per frame
	void Update () {
		Tempo += Time.deltaTime/Duracao;
		CorpoRigido.velocity = new Vector2(Velocidade, 0);
		if (Tempo >= 1) Destroy(GetComponent<Transform>().gameObject);
	}
}
