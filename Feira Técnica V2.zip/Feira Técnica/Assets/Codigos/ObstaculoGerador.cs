﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstaculoGerador : MonoBehaviour {
	public GameObject[] Obstaculos;
	public float Tempo;

	float Duracao;	

	void Start(){
		Duracao = Tempo;
	}
	
	// Update is called once per frame
	void Update () {
		if (Duracao > 0) Duracao -= Time.deltaTime;
		else{
			GameObject ObstaculoAl = Instantiate(Obstaculos[Random.Range(0, Obstaculos.Length)]);
			ObstaculoAl.transform.position = new Vector3(25, Random.Range(-7f, 7f), 0);
			ObstaculoAl.transform.parent = GetComponent<Transform>();
			Duracao = Tempo;
		}
	}
}
