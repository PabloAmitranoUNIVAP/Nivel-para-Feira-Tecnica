﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstaculoCodigo : MonoBehaviour {
	float XFinal;
	public float Velocidade, VelocidadeAngular;

	public int Vida;
	public bool Explosivo;

	Transform ObjetoTransform;
	public GameObject Explosao;

	Rigidbody2D CorpoRigido;	

	// Use this for initialization
	void Start () {
		ObjetoTransform = GetComponent<Transform>();
		CorpoRigido = GetComponent<Rigidbody2D>();
		CorpoRigido.angularVelocity = VelocidadeAngular;
		CorpoRigido.velocity = new Vector2(-Velocidade, 0);

		XFinal = ObjetoTransform.position.x - 60;
		if (Velocidade == 0){
			Velocidade = 1;
			print("Velocidade é nulo.");
		}
	}
	
	// Update is called once per frame
	void Update () {
		if (ObjetoTransform.position.x <= XFinal) Destroy(ObjetoTransform.gameObject);
		if (Vida <= 0){
			if (Explosivo == true){
				GameObject NovoExplosao = Instantiate(Explosao);
				NovoExplosao.transform.position = ObjetoTransform.position;
				Destroy(NovoExplosao, 0.2f);
			}
			Destroy(ObjetoTransform.gameObject);
		}
	}

	void OnTriggerEnter2D(Collider2D Colisor){
		GameObject Bala = Colisor.gameObject;

		if (Bala.CompareTag("Bala")){
			Vida -= 1;
			Destroy(Bala);
		}
		else if (Bala.CompareTag("PerigoExplosao")) Vida -= 5;
	}
}
