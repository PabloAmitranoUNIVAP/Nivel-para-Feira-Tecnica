﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cenario : MonoBehaviour {
    public GameObject NivelCenario, NivelFundo;
    public float XFinal, Desvio, Duracao;
    float Tempo;

    GameObject NivelCenario2;
    Vector3 Posicao;

    void Start()
    {
        NivelCenario2 = Instantiate(NivelCenario);
    }
	
	// Update is called once per frame
	void Update () {
       		Tempo += Time.deltaTime/Duracao;
        	Posicao = new Vector3(Mathf.Lerp(XFinal + Desvio, XFinal, Tempo), NivelCenario.transform.position.y, 0);
        	NivelCenario.transform.position = Posicao;
		NivelFundo.transform.position -= new Vector3(1e-3f, 0, 0);
        	NivelCenario2.transform.position = Posicao - new Vector3(Desvio, 0, 0);
        	if (Tempo >= 1) Tempo = 0;
	}
}
