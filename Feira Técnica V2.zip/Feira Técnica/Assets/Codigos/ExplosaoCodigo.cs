﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExplosaoCodigo : MonoBehaviour {
	Transform ExplosaoTransform;

	void Start(){
		ExplosaoTransform = GetComponent<Transform>();
	}

	void Update(){
		ExplosaoTransform.localScale += new Vector3(60*Time.deltaTime, 60*Time.deltaTime, 0);
	}
}
